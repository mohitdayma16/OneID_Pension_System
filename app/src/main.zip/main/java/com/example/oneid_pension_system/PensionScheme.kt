package com.example.oneid_pension_system

data class PensionScheme(
    val title: String,
    val description: String
)
