package com.example.oneid_pension_system

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class ApplicationStatusActivity : AppCompatActivity() {

    private lateinit var iconList: List<ImageView>
    private val sharedPrefKey = "PensionStatusStage"
    private val totalStages = 4

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_application_status)
        var back = findViewById<TextView>(R.id.AS_btnBack)
        back.setOnClickListener {
            val intent = Intent(this, MainActivity1::class.java)
            startActivity(intent)
            finish()
        }

        // Initialize icons from layout
        iconList = listOf(
            findViewById(R.id.step1Icon),
            findViewById(R.id.step2Icon),
            findViewById(R.id.step3Icon),
            findViewById(R.id.step4Icon)
        )

        // Retrieve saved stage or default to 1
        val currentStage = getSavedStage()

        // Update status view
        updateStageStatus(currentStage)

        // OPTIONAL: Advance to next stage on long press (for testing/demo)
        iconList.forEachIndexed { index, imageView ->
            imageView.setOnLongClickListener {
                val nextStage = (index + 2).coerceAtMost(totalStages)
                saveStage(nextStage)
                updateStageStatus(nextStage)
                true
            }
        }
    }

    private fun updateStageStatus(stage: Int) {
        val completedIcon = R.drawable.greentick
        val gray = Color.parseColor("#B0BEC5")

        iconList.forEachIndexed { index, icon ->
            when {
                index < stage -> {
                    icon.setImageResource(completedIcon)
                }
            }
        }
    }

    private fun saveStage(stage: Int) {
        val sharedPref = getSharedPreferences("OneIDPrefs", Context.MODE_PRIVATE)
        with(sharedPref.edit()) {
            putInt(sharedPrefKey, stage)
            apply()
        }
    }

    private fun getSavedStage(): Int {
        val sharedPref = getSharedPreferences("OneIDPrefs", Context.MODE_PRIVATE)
        return sharedPref.getInt(sharedPrefKey, 1)
    }
}
