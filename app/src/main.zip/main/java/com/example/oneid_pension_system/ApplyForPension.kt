package com.example.oneid_pension_system

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class ApplyForPension : AppCompatActivity() {

    private lateinit var rbKnowAppNo: RadioButton
    private lateinit var rbDontKnowAppNo: RadioButton
    private lateinit var loginForm: LinearLayout
    private lateinit var btnLogin: Button
    private lateinit var dateTextView: TextView
    private lateinit var etAppNumber: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apply_for_pension)

        var back = findViewById<TextView>(R.id.AP_btnBack)
        back.setOnClickListener {
            val intent = Intent(this, MainActivity1::class.java)
            startActivity(intent)
            finish()
        }

        rbKnowAppNo = findViewById(R.id.rbKnowAppNo)
        rbDontKnowAppNo = findViewById(R.id.rbDontKnowAppNo)
        loginForm = findViewById(R.id.loginForm)
        btnLogin = findViewById(R.id.btnLogin)
        dateTextView = findViewById(R.id.tvSelectedDate)
        etAppNumber = findViewById(R.id.etAppNumber)

        // Show login form only when "I know my application number" is selected
        rbKnowAppNo.setOnCheckedChangeListener { _, isChecked ->
            loginForm.visibility = if (isChecked) LinearLayout.VISIBLE else LinearLayout.GONE
        }

        // Go back to MainActivity when "I don't know my application number" is selected
        rbDontKnowAppNo.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            }
        }

        // Date picker dialog
        dateTextView.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePicker = DatePickerDialog(this, { _, y, m, d ->
                val formattedDate = "${String.format("%02d", d)}-${String.format("%02d", m + 1)}-$y"
                dateTextView.text = formattedDate
            }, year, month, day)
            datePicker.show()
        }

        // Login button click
        btnLogin.setOnClickListener {
            val appNumber = etAppNumber.text.toString().trim()
            val dob = dateTextView.text.toString().trim()

            if (appNumber.isEmpty() || dob == "Select Date") {
                Toast.makeText(this, "Please enter all details", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
